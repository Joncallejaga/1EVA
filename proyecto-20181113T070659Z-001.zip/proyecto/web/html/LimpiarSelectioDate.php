<?php
session_start();
unset($_SESSION["listaArticulos"]);
header("Location:index1.php");
?>

