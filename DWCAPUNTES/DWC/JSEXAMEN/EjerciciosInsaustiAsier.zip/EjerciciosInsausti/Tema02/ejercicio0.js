//Escribe por consola el Hola Mundo, no por pantalla
console.log("Hola Mundo!");

//Solicita un dato en un mensaje y lo muestra por consola
var a = prompt('Inserte un dato: ', '');
console.log(a.toString());